#ifndef __CONFIG_H
#define __CONFIG_H

#include "zf_common_typedef.h"





// ������Ŷ��壨ʹ����ɿ��ö�٣�
/*#define LEFT_MOTOR_PWM   PWMA_CH1P_P20
#define RIGHT_MOTOR_PWM  PWMA_CH2P_P22
#define LEFT_MOTOR_DIR   IO_P21
#define RIGHT_MOTOR_DIR  IO_P23*/

//==============================================================================
// ��ֵ����
//==============================================================================
/*#define THRESHOLD_BLACK   100
#define THRESHOLD_EDGE    500
#define THRESHOLD_CROSS   800

//==============================================================================
// �ٶȲ�����ע��PWM_DUTY_MAX=10000��
//==============================================================================
#define BASE_SPEED_NORMAL    2000    // 20%ռ�ձ�
#define BASE_SPEED_TURN      1500    // 15%ռ�ձ�
#define BASE_SPEED_FAST      3000    // 30%ռ�ձ�
#define MOTOR_SPEED_MAX      5000    // 50%ռ�ձ�

//==============================================================================
// ��������
//==============================================================================
#define CONTROL_CYCLE_MS     20
#define FILTER_WINDOW_SIZE   5*/

#endif