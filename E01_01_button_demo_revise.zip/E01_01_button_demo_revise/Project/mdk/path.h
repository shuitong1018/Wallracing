#ifndef __PATH_H
#define __PATH_H

#include "zf_common_headfile.h"

//==============================================================================
// ·������ö�٣�ȥ��UNKNOWN��
//==============================================================================
typedef enum {
    PATH_STRAIGHT = 0,      // ֱ��
    PATH_LEFT_ANGLE,        // ��ֱ��
    PATH_RIGHT_ANGLE,       // ��ֱ��
    PATH_CIRCULAR,          // Բ�����
    PATH_CROSSROAD,         // ʮ��·��
    PATH_ZIGZAG,            // ����
    PATH_ROUNDABOUT,        // ����
    PATH_FLAT,              // ƽ�أ����ߣ�
    PATH_TYPE_COUNT
} PathType_t;

//==============================================================================
// ·������ö��
//==============================================================================
typedef enum {
    DIR_LEFT = -1,
    DIR_STRAIGHT = 0,
    DIR_RIGHT = 1
} PathDirection_t;

//==============================================================================
// ���ƶ���ö��
//==============================================================================
typedef enum {
    ACTION_TRACKING = 0,        // ����ѭ��
    ACTION_TURN_LEFT_HARD,      // ��ת
    ACTION_TURN_RIGHT_HARD,     // �Ҽ�ת
    ACTION_TURN_LEFT_SMOOTH,    // ��ƽ��ת��
    ACTION_TURN_RIGHT_SMOOTH,   // ��ƽ��ת��
    ACTION_TRACKING_FAST,       // ����ѭ��
    ACTION_ROUNDABOUT,          // ����ģʽ
    ACTION_STOP,                // ֹͣ
    ACTION_FORWARD_STRAIGHT,    // ֱ�У���ѭ����
    ACTION_COUNT
} PathAction_t;

//==============================================================================
// ��������
//==============================================================================
void Path_Init(void);
PathType_t Path_Detect(float L1, float L2, float L3, float L4);
PathDirection_t Path_Get_Direction(float L1, float L2, float L3, float L4);
PathAction_t Path_Get_Action(PathType_t path, float L1, float L2, float L3, float L4);
const char* Path_GetName(PathType_t path);
const char* Action_GetName(PathAction_t action);
PathType_t Path_GetCurrent(void);
int Path_NeedSlowDown(PathType_t path);
float Path_GetSpeedFactor(PathType_t path);
void Path_Reset(void);
void Path_Debug_Print(float L1, float L2, float L3, float L4);

#endif //