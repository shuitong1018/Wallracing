/*#include "path.h"
#include "zf_common_headfile.h"

//==============================================================================
// ��������
//==============================================================================
// ����������
#define SENSOR_COUNT            4

// ��ʷ�������
#define HISTORY_DEPTH           5

// ��ֵ���� - ��Ҫ����ʵ�ʵ��Ե���
#define THRESHOLD_LINE_PRESENT      30.0f   // ��⵽�ߵ���ֵ
#define THRESHOLD_STRONG_SIGNAL     60.0f   // ǿ�ź���ֵ
#define THRESHOLD_WEAK_SIGNAL       15.0f   // ���ź���ֵ
#define THRESHOLD_LOST_LINE         10.0f   // ������ֵ
#define THRESHOLD_SIDE_DIFF         40.0f   // ���Ҳ������ֵ

// ״̬������ֵ
#define STRAIGHT_COUNT_THRESHOLD    3
#define ANGLE_COUNT_MAX             30
#define CIRCLE_COUNT_THRESHOLD      5
#define CROSS_COUNT_THRESHOLD       3
#define ROUNDABOUT_EDGE_MAX         6
#define LOST_LINE_MAX                20

// �����ֵ
#define ERROR_STRAIGHT_THRESHOLD    20.0f   // ֱ�������ֵ
#define ERROR_CIRCLE_THRESHOLD      50.0f   // ��������ֵ

//==============================================================================
// ���ݽṹ����
//==============================================================================
typedef struct {
    float values[4];          // L1,L2,L3,L4
    float error;              // ��Ӧ�����ֵ
    PathType_t detected_type;
    uint32_t timestamp;
} SensorHistory_t;

typedef struct {
    // ��������ʷ
    SensorHistory_t history[HISTORY_DEPTH];
    int history_index;
    
    // ·��״̬
    PathType_t current_path;
    PathType_t previous_path;
    int path_stable_count;
    
    // ����·��������
    int angle_counter;
    int cross_counter;
    int circle_counter;
    int roundabout_edge_counter;
    int lost_line_counter;
    int straight_counter;
    
    // ������־
    int left_bias_count;      // ���ƫ�ü���
    int right_bias_count;     // �Ҳ�ƫ�ü���
    float last_error;
    float last_valid_error;    // �ϴ���Ч���
    
    // ����״̬
    int in_roundabout;
    int roundabout_phase;      // 0:���,1:����,2:����
    int roundabout_edge_count;
    float roundabout_entry_error;
    
    // ������Ϣ
    uint32_t last_print_time;
    
} PathController_t;

//==============================================================================
// ��̬����
//==============================================================================
static PathController_t controller;
static const char* path_type_names[] = {
    "STRAIGHT", "LEFT_ANGLE", "RIGHT_ANGLE", "CIRCULAR",
    "CROSSROAD", "ZIGZAG", "ROUNDABOUT", "FLAT"
};

static const char* action_names[] = {
    "TRACKING", "TURN_LEFT_HARD", "TURN_RIGHT_HARD", "TURN_LEFT_SMOOTH",
    "TURN_RIGHT_SMOOTH", "TRACKING_FAST", "ROUNDABOUT", "STOP", "FORWARD_STRAIGHT"
};

//==============================================================================
// �ڲ���������
//==============================================================================
static void update_history(float L1, float L2, float L3, float L4, float error, PathType_t type);
static PathType_t get_stable_path_type(void);
static int detect_lost_line(float L1, float L2, float L3, float L4);
static int detect_crossroad(float L1, float L2, float L3, float L4);
static int detect_angle(float L1, float L2, float L3, float L4);
static int detect_circular(float L1, float L2, float L3, float L4, float error);
static int detect_zigzag(float L1, float L2, float L3, float L4, float error);
static int detect_roundabout(float L1, float L2, float L3, float L4);
static int get_bias_direction(float L1, float L2, float L3, float L4);
static int is_exiting_special_element(void);

//==============================================================================
// �ⲿ��������
//==============================================================================
extern float Error_Calculate(float L1_norm, float L2_norm, float L3_norm, float L4_norm);
extern float my_abs(float x);

//==============================================================================
// ·����ʼ��
//==============================================================================
void Path_Init(void)
{
    // ��ʼ��������
    memset(&controller, 0, sizeof(PathController_t));
    
    // ��ʼ����ʷ����
    for(int i = 0; i < HISTORY_DEPTH; i++) {
        controller.history[i].values[0] = 0;
        controller.history[i].values[1] = 0;
        controller.history[i].values[2] = 0;
        controller.history[i].values[3] = 0;
        controller.history[i].error = 0;
        controller.history[i].detected_type = PATH_STRAIGHT;  // Ĭ��ֱ��
        controller.history[i].timestamp = 0;
    }
    
    controller.history_index = 0;
    controller.current_path = PATH_STRAIGHT;
    controller.previous_path = PATH_STRAIGHT;
    controller.path_stable_count = 0;
    
    controller.angle_counter = 0;
    controller.cross_counter = 0;
    controller.circle_counter = 0;
    controller.roundabout_edge_counter = 0;
    controller.lost_line_counter = 0;
    controller.straight_counter = 0;
    
    controller.left_bias_count = 0;
    controller.right_bias_count = 0;
    controller.last_error = 0;
    controller.last_valid_error = 0;
    
    controller.in_roundabout = 0;
    controller.roundabout_phase = 0;
    controller.roundabout_edge_count = 0;
    controller.roundabout_entry_error = 0;
    
    controller.last_print_time = 0;
}

//==============================================================================
// ��ǿ��·�����ͼ��
//==============================================================================
PathType_t Path_Detect(float L1, float L2, float L3, float L4)
{
    PathType_t detected = PATH_STRAIGHT;  // Ĭ��ֱ��
    float error = Error_Calculate(L1, L2, L3, L4);
    
    // 1. ����Ƿ��ߣ����е���źŶ�������
    if(detect_lost_line(L1, L2, L3, L4)) {
        controller.lost_line_counter++;
        
        // ������·���ж����������ģ���Ҫ�����ʷ״̬�ж�
        if(controller.current_path == PATH_LEFT_ANGLE || 
           controller.current_path == PATH_RIGHT_ANGLE ||
           controller.current_path == PATH_ROUNDABOUT) {
            // ����򻷵�ʱ��������������״̬
            detected = controller.current_path;
            update_history(L1, L2, L3, L4, error, detected);
            return detected;
        }
        
        // ���ݶ��߿���ֻ�ǻζ�
        if(controller.lost_line_counter < 5) {
            detected = controller.current_path;
        } else {
            detected = PATH_FLAT;
        }
        
        update_history(L1, L2, L3, L4, error, detected);
        return detected;
    } else {
        controller.lost_line_counter = 0;
    }
    
    // 2. ���ʮ��·�ڣ��ĸ���ж��н�ǿ�źţ�
    if(detect_crossroad(L1, L2, L3, L4)) {
        controller.cross_counter++;
        if(controller.cross_counter > CROSS_COUNT_THRESHOLD) {
            detected = PATH_CROSSROAD;
            update_history(L1, L2, L3, L4, error, detected);
            return detected;
        }
    } else {
        controller.cross_counter = 0;
    }
    
    // 3. ��⻷��
    if(detect_roundabout(L1, L2, L3, L4)) {
        detected = PATH_ROUNDABOUT;
        update_history(L1, L2, L3, L4, error, detected);
        return detected;
    }
    
    // 4. ���ֱ����
    if(detect_angle(L1, L2, L3, L4)) {
        int direction = get_bias_direction(L1, L2, L3, L4);
        if(direction < 0) {
            detected = PATH_LEFT_ANGLE;
        } else if(direction > 0) {
            detected = PATH_RIGHT_ANGLE;
        }
        
        if(detected != PATH_STRAIGHT) {
            controller.angle_counter++;
            update_history(L1, L2, L3, L4, error, detected);
            return detected;
        }
    }
    
    // 5. ���Բ�����
    if(detect_circular(L1, L2, L3, L4, error)) {
        detected = PATH_CIRCULAR;
        update_history(L1, L2, L3, L4, error, detected);
        return detected;
    }
    
    // 6. �������
    if(detect_zigzag(L1, L2, L3, L4, error)) {
        detected = PATH_ZIGZAG;
        update_history(L1, L2, L3, L4, error, detected);
        return detected;
    }
    
    // 7. Ĭ�Ϸ���ֱ��
    detected = PATH_STRAIGHT;
    controller.straight_counter++;
    update_history(L1, L2, L3, L4, error, detected);
    
    return detected;
}

//==============================================================================
// ��ⶪ�����
//==============================================================================
static int detect_lost_line(float L1, float L2, float L3, float L4)
{
    return (L1 < THRESHOLD_LOST_LINE && L2 < THRESHOLD_LOST_LINE && 
            L3 < THRESHOLD_LOST_LINE && L4 < THRESHOLD_LOST_LINE);
}

//==============================================================================
// ���ʮ��·��
//==============================================================================
static int detect_crossroad(float L1, float L2, float L3, float L4)
{
    // ʮ��·���������ĸ���ж��н�ǿ�źţ����м���������ź�ǿ������
    float middle_avg = (L2 + L3) / 2.0f;
    float side_avg = (L1 + L4) / 2.0f;
    
    return (L1 > THRESHOLD_STRONG_SIGNAL && 
            L2 > THRESHOLD_STRONG_SIGNAL && 
            L3 > THRESHOLD_STRONG_SIGNAL && 
            L4 > THRESHOLD_STRONG_SIGNAL &&
            middle_avg > side_avg * 1.2f);
}

//==============================================================================
// ���ֱ����
//==============================================================================
static int detect_angle(float L1, float L2, float L3, float L4)
{
    // ֱ����������ĳһ�����źź�ǿ����һ�����
    float left_sum = L1 + L2;
    float right_sum = L3 + L4;
    float side_diff = my_abs(left_sum - right_sum);
    
    // ���Ҳ�����ҵ����ź�ǿ
    if(side_diff > THRESHOLD_SIDE_DIFF * 2) {
        if((L1 > THRESHOLD_STRONG_SIGNAL && L4 < THRESHOLD_WEAK_SIGNAL) ||
           (L4 > THRESHOLD_STRONG_SIGNAL && L1 < THRESHOLD_WEAK_SIGNAL)) {
            return 1;
        }
    }
    
    return 0;
}

//==============================================================================
// ���Բ�����
//==============================================================================
static int detect_circular(float L1, float L2, float L3, float L4, float error)
{
    // Բ����������������Ľϴ����������ȶ�
    static int same_direction_count = 0;
    static float last_error_direction = 0;
    
    float current_direction = (error > 0) ? 1 : ((error < 0) ? -1 : 0);
    
    // ����㹻���ҷ���һ��
    if(my_abs(error) > ERROR_CIRCLE_THRESHOLD) {
        if(current_direction == last_error_direction) {
            same_direction_count++;
        } else {
            same_direction_count = 1;
        }
    } else {
        same_direction_count = 0;
    }
    
    last_error_direction = current_direction;
    
    return (same_direction_count > CIRCLE_COUNT_THRESHOLD);
}

//==============================================================================
// �������
//==============================================================================
static int detect_zigzag(float L1, float L2, float L3, float L4, float error)
{
    // ���������������ٱ仯
    static float last_error = 0;
    static int change_count = 0;
    
    float error_change = my_abs(error - last_error);
    
    if(error_change > 50.0f) {  // ���仯��
        change_count++;
        if(change_count > 3) {
            change_count = 0;
            last_error = error;
            return 1;
        }
    } else {
        change_count = 0;
    }
    
    last_error = error;
    return 0;
}

//==============================================================================
// ��⻷��
//==============================================================================
static int detect_roundabout(float L1, float L2, float L3, float L4)
{
    // ������������ʱ��ĵ���ƫ��
    int direction = get_bias_direction(L1, L2, L3, L4);
    
    if(direction < 0) {  // ��ƫ
        controller.left_bias_count++;
        controller.right_bias_count = 0;
    } else if(direction > 0) {  // ��ƫ
        controller.right_bias_count++;
        controller.left_bias_count = 0;
    } else {
        // ���ݻ��в���������
        if(controller.left_bias_count > 0) {
            controller.left_bias_count = controller.left_bias_count > 2 ? controller.left_bias_count - 1 : 0;
        }
        if(controller.right_bias_count > 0) {
            controller.right_bias_count = controller.right_bias_count > 2 ? controller.right_bias_count - 1 : 0;
        }
    }
    
    // �������ͬ��ƫ�ã������ǻ���
    if(controller.left_bias_count > 8 || controller.right_bias_count > 8) {
        return 1;
    }
    
    return 0;
}

//==============================================================================
// ��ȡƫ�÷���
//==============================================================================
static int get_bias_direction(float L1, float L2, float L3, float L4)
{
    float left_strength = L1 + L2;
    float right_strength = L3 + L4;
    
    if(left_strength > right_strength + THRESHOLD_SIDE_DIFF) {
        return -1;  // ��ƫ
    } else if(right_strength > left_strength + THRESHOLD_SIDE_DIFF) {
        return 1;   // ��ƫ
    } else {
        return 0;   // ����
    }
}

//==============================================================================
// ���´�������ʷ
//==============================================================================
static void update_history(float L1, float L2, float L3, float L4, float error, PathType_t type)
{
    controller.history_index = (controller.history_index + 1) % HISTORY_DEPTH;
    
    controller.history[controller.history_index].values[0] = L1;
    controller.history[controller.history_index].values[1] = L2;
    controller.history[controller.history_index].values[2] = L3;
    controller.history[controller.history_index].values[3] = L4;
    controller.history[controller.history_index].error = error;
    controller.history[controller.history_index].detected_type = type;
    controller.history[controller.history_index].timestamp = systick_get_ms();
}

//==============================================================================
// ��ȡ�ȶ���·������
//==============================================================================
static PathType_t get_stable_path_type(void)
{
    int count[PATH_TYPE_COUNT] = {0};
    int max_count = 0;
    PathType_t stable_type = PATH_STRAIGHT;
    
    // ͳ����ʷ����
    for(int i = 0; i < HISTORY_DEPTH; i++) {
        PathType_t type = controller.history[i].detected_type;
        if(type < PATH_TYPE_COUNT) {
            count[type]++;
        }
    }
    
    // �ҳ��ִ�����������
    for(int i = 0; i < PATH_TYPE_COUNT; i++) {
        if(count[i] > max_count) {
            max_count = count[i];
            stable_type = (PathType_t)i;
        }
    }
    
    // ��Ҫ�ﵽһ�����Ŷȣ����򱣳ֵ�ǰ·��
    if(max_count < HISTORY_DEPTH / 2) {
        return controller.current_path;
    }
    
    return stable_type;
}

//==============================================================================
// ��ȡ·������
//==============================================================================
PathDirection_t Path_Get_Direction(float L1, float L2, float L3, float L4)
{
    float error = Error_Calculate(L1, L2, L3, L4);
    
    if(error < -ERROR_STRAIGHT_THRESHOLD) {
        return DIR_LEFT;
    } else if(error > ERROR_STRAIGHT_THRESHOLD) {
        return DIR_RIGHT;
    } else {
        return DIR_STRAIGHT;
    }
}

//==============================================================================
// ��ȡ���ƶ���
//==============================================================================
PathAction_t Path_Get_Action(PathType_t path, float L1, float L2, float L3, float L4)
{
    PathAction_t action = ACTION_TRACKING;
    float error = Error_Calculate(L1, L2, L3, L4);
    int direction = get_bias_direction(L1, L2, L3, L4);
    
    // ����·��״̬
    controller.previous_path = controller.current_path;
    PathType_t stable_path = get_stable_path_type();
    if(stable_path != controller.current_path) {
        // ·���仯ʱ���ʵ���ʱȷ��
        controller.path_stable_count++;
        if(controller.path_stable_count > STRAIGHT_COUNT_THRESHOLD) {
            controller.current_path = stable_path;
            controller.path_stable_count = 0;
        }
    } else {
        controller.path_stable_count = 0;
    }
    
    // ������Ч���Ƕ���ʱ��
    if(!detect_lost_line(L1, L2, L3, L4)) {
        controller.last_valid_error = error;
    }
    
    // ���ݲ�ͬ·���������ɿ��ƶ���
    switch(controller.current_path)
    {
        case PATH_STRAIGHT:
            // ֱ��������ѭ��
            action = ACTION_TRACKING;
            controller.angle_counter = 0;
            controller.circle_counter = 0;
            controller.roundabout_edge_counter = 0;
            break;
            
        case PATH_LEFT_ANGLE:
            // ��ֱ����
            controller.angle_counter++;
            
            if(controller.angle_counter < 10) {
                // ������ڣ�ǿת��
                action = ACTION_TURN_LEFT_HARD;
            } else if(controller.angle_counter < 25) {
                // ����У�����ת��
                action = ACTION_TURN_LEFT_HARD;
            } else {
                // ׼������
                action = ACTION_TRACKING;
            }
            
            // �����ж�
            if(controller.angle_counter > ANGLE_COUNT_MAX || 
               (my_abs(error) < ERROR_STRAIGHT_THRESHOLD && controller.angle_counter > 15)) {
                controller.angle_counter = 0;
            }
            break;
            
        case PATH_RIGHT_ANGLE:
            // ��ֱ����
            controller.angle_counter++;
            
            if(controller.angle_counter < 10) {
                action = ACTION_TURN_RIGHT_HARD;
            } else if(controller.angle_counter < 25) {
                action = ACTION_TURN_RIGHT_HARD;
            } else {
                action = ACTION_TRACKING;
            }
            
            if(controller.angle_counter > ANGLE_COUNT_MAX || 
               (my_abs(error) < ERROR_STRAIGHT_THRESHOLD && controller.angle_counter > 15)) {
                controller.angle_counter = 0;
            }
            break;
            
        case PATH_CIRCULAR:
            // Բ�������ƽ��ת��
            controller.circle_counter++;
            if(error < -ERROR_CIRCLE_THRESHOLD) {
                action = ACTION_TURN_LEFT_SMOOTH;
            } else if(error > ERROR_CIRCLE_THRESHOLD) {
                action = ACTION_TURN_RIGHT_SMOOTH;
            } else {
                action = ACTION_TRACKING;
            }
            break;
            
        case PATH_CROSSROAD:
            // ʮ��·�ڣ�����ֱ��
            action = ACTION_FORWARD_STRAIGHT;
            controller.cross_counter++;
            
            // ��ʮ���ж�
            if(controller.cross_counter > CROSS_COUNT_THRESHOLD * 3) {
                controller.cross_counter = 0;
            }
            break;
            
        case PATH_ZIGZAG:
            // ���ߣ�������Ӧ
            if(my_abs(error) > ERROR_CIRCLE_THRESHOLD * 1.5f) {
                if(error < 0) {
                    action = ACTION_TURN_LEFT_HARD;
                } else {
                    action = ACTION_TURN_RIGHT_HARD;
                }
            } else {
                action = ACTION_TRACKING_FAST;
            }
            break;
            
        case PATH_ROUNDABOUT:
            // ��������
            if(!controller.in_roundabout) {
                // �״ν��뻷��
                controller.in_roundabout = 1;
                controller.roundabout_phase = 0;  // ���
                controller.roundabout_edge_count = 0;
                controller.roundabout_entry_error = error;
            }
            
            // ������ѭ��
            if(controller.roundabout_phase == 0) {
                // ��ڽ׶Σ����ݽ��뷽��ת��
                if(controller.left_bias_count > controller.right_bias_count) {
                    action = ACTION_TURN_LEFT_SMOOTH;
                } else {
                    action = ACTION_TURN_RIGHT_SMOOTH;
                }
                
                // ���뻷�����л�״̬
                if(my_abs(error) > ERROR_CIRCLE_THRESHOLD * 1.5f) {
                    controller.roundabout_phase = 1;  // ���뵺��
                }
            } else if(controller.roundabout_phase == 1) {
                // ���ڽ׶Σ��ȶ�ѭ��
                if(direction < 0) {
                    action = ACTION_TURN_LEFT_SMOOTH;
                } else if(direction > 0) {
                    action = ACTION_TURN_RIGHT_SMOOTH;
                } else {
                    action = ACTION_TRACKING;
                }
                
                // ��⻷�����أ����߼�����
                if(detect_lost_line(L1, L2, L3, L4)) {
                    controller.roundabout_edge_count++;
                }
            }
            
            // �������ڼ��
            if(controller.roundabout_edge_count >= ROUNDABOUT_EDGE_MAX) {
                // ׼��������
                controller.roundabout_phase = 2;
                action = ACTION_FORWARD_STRAIGHT;
                
                // ��ȫ�˳�����
                if(my_abs(error) < ERROR_STRAIGHT_THRESHOLD) {
                    controller.in_roundabout = 0;
                    controller.roundabout_phase = 0;
                    controller.roundabout_edge_count = 0;
                }
            }
            break;
            
        case PATH_FLAT:
            // ƽ��/���ߣ���������
            controller.lost_line_counter++;
            if(controller.lost_line_counter < 10) {
                // ���ݶ��ߣ�ʹ���ϴ���Ч������ѭ��
                action = ACTION_TRACKING;
            } else {
                // ��ʱ�䶪�ߣ�ֹͣ
                action = ACTION_STOP;
            }
            break;
            
        default:
            action = ACTION_TRACKING;
            break;
    }
    
    controller.last_error = error;
    return action;
}

//==============================================================================
// ��ȡ��ǰ·������
//==============================================================================
const char* Path_GetName(PathType_t path)
{
    if(path >= 0 && path < PATH_TYPE_COUNT) {
        return path_type_names[path];
    }
    return "UNKNOWN";
}

//==============================================================================
// ��ȡ��������
//==============================================================================
const char* Action_GetName(PathAction_t action)
{
    if(action >= 0 && action < ACTION_COUNT) {
        return action_names[action];
    }
    return "UNKNOWN";
}

//==============================================================================
// ��ȡ��ǰ·��״̬
//==============================================================================
PathType_t Path_GetCurrent(void)
{
    return controller.current_path;
}

//==============================================================================
// �ж��Ƿ���Ҫ����
//==============================================================================
int Path_NeedSlowDown(PathType_t path)
{
    switch(path) {
        case PATH_LEFT_ANGLE:
        case PATH_RIGHT_ANGLE:
        case PATH_ZIGZAG:
            return 2;  // �������
        case PATH_ROUNDABOUT:
            return 3;  // ������
        case PATH_CIRCULAR:
            return 1;  // ��΢����
        case PATH_CROSSROAD:
            return 1;  // ��΢����
        default:
            return 0;  // ����Ҫ����
    }
}

//==============================================================================
// ��ȡ�Ƽ��ٶ�ϵ��
//==============================================================================
float Path_GetSpeedFactor(PathType_t path)
{
    switch(path) {
        case PATH_STRAIGHT:
            return 1.0f;      // ȫ��
        case PATH_CIRCULAR:
            return 0.7f;      // 70%�ٶ�
        case PATH_CROSSROAD:
            return 0.6f;      // 60%�ٶ�
        case PATH_LEFT_ANGLE:
        case PATH_RIGHT_ANGLE:
            return 0.4f;      // 40%�ٶ�
        case PATH_ZIGZAG:
            return 0.35f;     // 35%�ٶ�
        case PATH_ROUNDABOUT:
            return 0.3f;      // 30%�ٶ�
        case PATH_FLAT:
            return 0.2f;      // 20%�ٶ�
        default:
            return 0.6f;
    }
}

//==============================================================================
// ����·�����״̬
//==============================================================================
void Path_Reset(void)
{
    Path_Init();
}

//==============================================================================
// ·��������Ϣ��ӡ
//==============================================================================
void Path_Debug_Print(float L1, float L2, float L3, float L4)
{
    uint32_t current_time = systick_get_ms();
    
    // ÿ200ms��ӡһ��
    if(current_time - controller.last_print_time > 200) {
        controller.last_print_time = current_time;
        
        float error = Error_Calculate(L1, L2, L3, L4);
        PathType_t current = Path_GetCurrent();
        PathDirection_t dir = Path_Get_Direction(L1, L2, L3, L4);
        
        printf("Path: %s, Dir: %d, Error: %.1f, L1:%.1f L2:%.1f L3:%.1f L4:%.1f\r\n",
               Path_GetName(current), dir, error, L1, L2, L3, L4);
        
        // ��ӡ����״̬
        if(controller.in_roundabout) {
            printf("Roundabout: Phase=%d, Edge=%d\r\n", 
                   controller.roundabout_phase, controller.roundabout_edge_count);
        }
        
        // ��ӡƫ�ü���
        if(controller.left_bias_count > 0 || controller.right_bias_count > 0) {
            printf("Bias: L=%d, R=%d\r\n", controller.left_bias_count, controller.right_bias_count);
        }
    }
}*/